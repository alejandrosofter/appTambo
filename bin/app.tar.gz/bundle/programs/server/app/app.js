var require = meteorInstall({"lib":{"collections.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// lib/collections.js                                                                                             //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Settings = new Mongo.Collection('settings');                                                                      // 1
Liquidaciones = new Mongo.Collection('liquidaciones');                                                            // 2
Nomencladores = new Mongo.Collection('nomencladores');                                                            // 3
ObrasSociales = new Mongo.Collection('obrasSociales');                                                            // 4
Pacientes = new Mongo.Collection('pacientes');                                                                    // 5
Animales = new Mongo.Collection('animales');                                                                      // 7
Rodeos = new Mongo.Collection('rodeos');                                                                          // 8
Especies = new Mongo.Collection('especies');                                                                      // 9
Potreros = new Mongo.Collection('potreros');                                                                      // 10
EventosMasivos = new Mongo.Collection('eventosMasivos');                                                          // 11
EventosMasivos.attachSchema(new SimpleSchema({                                                                    // 13
  estado: {                                                                                                       // 14
    type: String,                                                                                                 // 15
    label: 'Estado',                                                                                              // 16
    autoform: {                                                                                                   // 17
      type: "select2",                                                                                            // 18
      options: function () {                                                                                      // 19
        return [{                                                                                                 // 20
          label: "APLICADO",                                                                                      // 20
          value: "APLICADO"                                                                                       // 20
        }, {                                                                                                      // 20
          label: "PARA APLICAR",                                                                                  // 20
          value: "PARA APLICAR"                                                                                   // 20
        }];                                                                                                       // 20
      },                                                                                                          // 21
      style: "width:180px"                                                                                        // 22
    }                                                                                                             // 17
  },                                                                                                              // 14
  tipoEvento: {                                                                                                   // 25
    type: String,                                                                                                 // 26
    label: "Tipo Evento",                                                                                         // 27
    autoform: {                                                                                                   // 28
      type: "select-radio",                                                                                       // 29
      options: function () {                                                                                      // 30
        return [{                                                                                                 // 31
          label: "PESAJE",                                                                                        // 31
          value: "PESAJE"                                                                                         // 31
        }, {                                                                                                      // 31
          label: "INSEMINADA",                                                                                    // 31
          value: "INSEMINADA"                                                                                     // 31
        }, {                                                                                                      // 31
          label: "CAMBIO POTRERO",                                                                                // 31
          value: "CAMBIO POTRERO"                                                                                 // 31
        }, {                                                                                                      // 31
          label: "MEDICACION",                                                                                    // 31
          value: "MEDICACION"                                                                                     // 31
        }, {                                                                                                      // 31
          label: "INSEMINA",                                                                                      // 31
          value: "INSEMINA"                                                                                       // 31
        }, {                                                                                                      // 31
          label: "PREÑADA",                                                                                       // 31
          value: "PREÑADA"                                                                                        // 31
        }, {                                                                                                      // 31
          label: "FALLECE",                                                                                       // 31
          value: "FALLECE"                                                                                        // 31
        }, {                                                                                                      // 31
          label: "VENTA",                                                                                         // 31
          value: "VENTA"                                                                                          // 31
        }, {                                                                                                      // 31
          label: "OTROS",                                                                                         // 31
          value: "OTROS"                                                                                          // 31
        }];                                                                                                       // 31
      },                                                                                                          // 32
      style: "width:250px"                                                                                        // 33
    }                                                                                                             // 28
  },                                                                                                              // 25
  fecha: {                                                                                                        // 36
    type: Date,                                                                                                   // 37
    label: 'Fecha Evento'                                                                                         // 38
  },                                                                                                              // 36
  detalle: {                                                                                                      // 40
    type: String,                                                                                                 // 41
    label: 'Detalle',                                                                                             // 42
    optional: true                                                                                                // 43
  },                                                                                                              // 40
  animales: {                                                                                                     // 45
    type: Array,                                                                                                  // 46
    optional: true                                                                                                // 47
  },                                                                                                              // 45
  "animales.$": {                                                                                                 // 49
    type: Object                                                                                                  // 50
  },                                                                                                              // 49
  "animales.$._id": {                                                                                             // 52
    type: String,                                                                                                 // 54
    autoValue: function () {                                                                                      // 55
      return Meteor.uuid();                                                                                       // 56
    }                                                                                                             // 57
  },                                                                                                              // 52
  "animales.$.idAnimal": {                                                                                        // 60
    type: String,                                                                                                 // 62
    label: "Detalle",                                                                                             // 63
    optional: true                                                                                                // 64
  },                                                                                                              // 60
  "animales.$.idAnimal": {                                                                                        // 66
    type: String,                                                                                                 // 67
    decimal: true,                                                                                                // 68
    optional: false,                                                                                              // 69
    label: "Animal",                                                                                              // 70
    autoform: {                                                                                                   // 71
      type: "select2",                                                                                            // 72
      options: function () {                                                                                      // 73
        return _.map(Animales.find().fetch(), function (c, i) {                                                   // 74
          return {                                                                                                // 75
            label: c.nombre + " " + c.carabana,                                                                   // 75
            value: c._id                                                                                          // 75
          };                                                                                                      // 75
        });                                                                                                       // 76
      },                                                                                                          // 76
      style: "width:200px"                                                                                        // 77
    }                                                                                                             // 71
  },                                                                                                              // 66
  "animales.$.valor": {                                                                                           // 83
    type: String,                                                                                                 // 84
    label: 'Valor',                                                                                               // 85
    optional: true                                                                                                // 86
  },                                                                                                              // 83
  "animales.$.idEventoAnimal": {                                                                                  // 89
    type: String,                                                                                                 // 90
    label: 'ID evento Animal',                                                                                    // 91
    optional: true                                                                                                // 92
  }                                                                                                               // 89
}));                                                                                                              // 13
Potreros.attachSchema(new SimpleSchema({                                                                          // 97
  fechaUpdate: {                                                                                                  // 100
    type: Date,                                                                                                   // 101
    label: 'Fecha Update',                                                                                        // 102
    optional: true                                                                                                // 103
  },                                                                                                              // 100
  nombrePotrero: {                                                                                                // 105
    type: String,                                                                                                 // 106
    label: 'Nombre'                                                                                               // 107
  },                                                                                                              // 105
  superficie: {                                                                                                   // 109
    type: String,                                                                                                 // 110
    label: 'Sup2.'                                                                                                // 111
  },                                                                                                              // 109
  detalle: {                                                                                                      // 113
    type: String,                                                                                                 // 114
    label: 'Detalle',                                                                                             // 115
    optional: true                                                                                                // 116
  },                                                                                                              // 113
  animales: {                                                                                                     // 118
    type: Array,                                                                                                  // 119
    optional: true                                                                                                // 120
  },                                                                                                              // 118
  "animales.$": {                                                                                                 // 122
    type: Object                                                                                                  // 123
  },                                                                                                              // 122
  "animales.$._id": {                                                                                             // 125
    type: String,                                                                                                 // 127
    autoValue: function () {                                                                                      // 128
      return Meteor.uuid();                                                                                       // 129
    }                                                                                                             // 130
  },                                                                                                              // 125
  "animales.$.detalle": {                                                                                         // 133
    type: String,                                                                                                 // 135
    label: "Detalle",                                                                                             // 136
    optional: true                                                                                                // 137
  },                                                                                                              // 133
  "animales.$.idAnimal": {                                                                                        // 139
    type: String,                                                                                                 // 140
    decimal: true,                                                                                                // 141
    optional: false,                                                                                              // 142
    label: "Animal",                                                                                              // 143
    autoform: {                                                                                                   // 144
      type: "select2",                                                                                            // 145
      options: function () {                                                                                      // 146
        return _.map(Animales.find().fetch(), function (c, i) {                                                   // 147
          return {                                                                                                // 148
            label: c.nombre + " " + c.carabana,                                                                   // 148
            value: c._id                                                                                          // 148
          };                                                                                                      // 148
        });                                                                                                       // 149
      },                                                                                                          // 149
      style: "width:200px"                                                                                        // 150
    }                                                                                                             // 144
  },                                                                                                              // 139
  "animales.$.fecha": {                                                                                           // 155
    type: Date,                                                                                                   // 156
    label: 'Fecha',                                                                                               // 157
    optional: false                                                                                               // 158
  },                                                                                                              // 155
  rodeos: {                                                                                                       // 161
    type: Array,                                                                                                  // 162
    optional: true                                                                                                // 163
  },                                                                                                              // 161
  "rodeos.$": {                                                                                                   // 165
    type: Object                                                                                                  // 166
  },                                                                                                              // 165
  "rodeos.$._id": {                                                                                               // 168
    type: String,                                                                                                 // 170
    autoValue: function () {                                                                                      // 171
      return Meteor.uuid();                                                                                       // 172
    }                                                                                                             // 173
  },                                                                                                              // 168
  "rodeos.$.idEspecie": {                                                                                         // 176
    type: String,                                                                                                 // 177
    decimal: true,                                                                                                // 178
    optional: false,                                                                                              // 179
    label: "Grupo",                                                                                               // 180
    autoform: {                                                                                                   // 181
      type: "select2",                                                                                            // 182
      options: function () {                                                                                      // 183
        return _.map(Especies.find().fetch(), function (c, i) {                                                   // 184
          return {                                                                                                // 185
            label: c.nombreEspecie,                                                                               // 185
            value: c._id                                                                                          // 185
          };                                                                                                      // 185
        });                                                                                                       // 186
      },                                                                                                          // 186
      style: "width:200px"                                                                                        // 187
    }                                                                                                             // 181
  },                                                                                                              // 176
  "rodeos.$.fecha": {                                                                                             // 192
    type: Date,                                                                                                   // 193
    label: 'Fecha',                                                                                               // 194
    optional: false                                                                                               // 195
  }                                                                                                               // 192
}));                                                                                                              // 97
Especies.attachSchema(new SimpleSchema({                                                                          // 199
  fechaUpdate: {                                                                                                  // 202
    type: Date,                                                                                                   // 203
    label: 'Fecha Update',                                                                                        // 204
    optional: true                                                                                                // 205
  },                                                                                                              // 202
  nombreEspecie: {                                                                                                // 207
    type: String,                                                                                                 // 208
    label: 'Nombre'                                                                                               // 209
  },                                                                                                              // 207
  esReproductor: {                                                                                                // 211
    type: Boolean,                                                                                                // 212
    label: 'Son Reproductores'                                                                                    // 213
  },                                                                                                              // 211
  inseminada: {                                                                                                   // 215
    type: Boolean,                                                                                                // 216
    label: 'Estan Inseminadas'                                                                                    // 217
  },                                                                                                              // 215
  enCelo: {                                                                                                       // 219
    type: Boolean,                                                                                                // 220
    label: 'Tienen Celo'                                                                                          // 221
  },                                                                                                              // 219
  preniada: {                                                                                                     // 223
    type: Boolean,                                                                                                // 224
    label: 'Estan Preniadas'                                                                                      // 225
  },                                                                                                              // 223
  genetica: {                                                                                                     // 227
    type: String,                                                                                                 // 228
    label: 'Genetica',                                                                                            // 229
    optional: true                                                                                                // 230
  },                                                                                                              // 227
  desdeMeses: {                                                                                                   // 232
    type: Number,                                                                                                 // 233
    label: 'Desde Meses'                                                                                          // 234
  },                                                                                                              // 232
  hastaMeses: {                                                                                                   // 236
    type: Number,                                                                                                 // 237
    label: 'Hasta Meses'                                                                                          // 238
  },                                                                                                              // 236
  genero: {                                                                                                       // 240
    type: String,                                                                                                 // 241
    label: 'Genero',                                                                                              // 242
    autoform: {                                                                                                   // 243
      type: "select-radio-inline",                                                                                // 244
      options: function () {                                                                                      // 245
        return [{                                                                                                 // 246
          label: "MACHO       ",                                                                                  // 246
          value: "MACHO"                                                                                          // 246
        }, {                                                                                                      // 246
          label: "HEMBRA",                                                                                        // 246
          value: "HEMBRA"                                                                                         // 246
        }];                                                                                                       // 246
      },                                                                                                          // 247
      style: "width:250px"                                                                                        // 248
    }                                                                                                             // 243
  }                                                                                                               // 240
}));                                                                                                              // 199
Rodeos.attachSchema(new SimpleSchema({                                                                            // 252
  fechaUpdate: {                                                                                                  // 254
    type: Date,                                                                                                   // 255
    label: 'Fecha Update',                                                                                        // 256
    optional: true                                                                                                // 257
  },                                                                                                              // 254
  nombreRodeo: {                                                                                                  // 259
    type: String,                                                                                                 // 260
    label: 'Nombre'                                                                                               // 261
  },                                                                                                              // 259
  idEspecie: {                                                                                                    // 263
    type: String,                                                                                                 // 264
    decimal: true,                                                                                                // 265
    optional: true,                                                                                               // 266
    label: "Especie",                                                                                             // 267
    autoform: {                                                                                                   // 268
      type: "select2",                                                                                            // 269
      options: function () {                                                                                      // 270
        return _.map(Especies.find().fetch(), function (c, i) {                                                   // 271
          return {                                                                                                // 272
            label: c.nombreEspecie,                                                                               // 272
            value: c._id                                                                                          // 272
          };                                                                                                      // 272
        });                                                                                                       // 273
      },                                                                                                          // 273
      style: "width:150px"                                                                                        // 274
    }                                                                                                             // 268
  },                                                                                                              // 263
  descripcion: {                                                                                                  // 279
    type: String,                                                                                                 // 280
    optional: true,                                                                                               // 281
    label: 'Descripcion'                                                                                          // 282
  },                                                                                                              // 279
  desdeMeses: {                                                                                                   // 284
    type: Number,                                                                                                 // 285
    label: 'Desde Meses'                                                                                          // 286
  },                                                                                                              // 284
  hastaMeses: {                                                                                                   // 288
    type: Number,                                                                                                 // 289
    label: 'Hasta Meses'                                                                                          // 290
  },                                                                                                              // 288
  idEspecie: {                                                                                                    // 292
    type: String,                                                                                                 // 293
    decimal: true,                                                                                                // 294
    optional: false,                                                                                              // 295
    label: "Especie",                                                                                             // 296
    autoform: {                                                                                                   // 297
      type: "select2",                                                                                            // 298
      options: function () {                                                                                      // 299
        return _.map(Especies.find().fetch(), function (c, i) {                                                   // 300
          return {                                                                                                // 301
            label: c.nombreEspecie,                                                                               // 301
            value: c._id                                                                                          // 301
          };                                                                                                      // 301
        });                                                                                                       // 302
      },                                                                                                          // 302
      style: "width:250px"                                                                                        // 303
    }                                                                                                             // 297
  },                                                                                                              // 292
  color: {                                                                                                        // 306
    type: String,                                                                                                 // 307
    label: 'Color'                                                                                                // 308
  }                                                                                                               // 306
}));                                                                                                              // 252
Animales.attachSchema(new SimpleSchema({                                                                          // 312
  eventos: {                                                                                                      // 314
    type: Array,                                                                                                  // 315
    optional: true                                                                                                // 316
  },                                                                                                              // 314
  "eventos.$": {                                                                                                  // 318
    type: Object                                                                                                  // 319
  },                                                                                                              // 318
  "eventos.$._id": {                                                                                              // 321
    type: String,                                                                                                 // 323
    label: "ID"                                                                                                   // 324
  },                                                                                                              // 321
  "eventos.$.fecha": {                                                                                            // 327
    type: Date,                                                                                                   // 328
    autoform: {                                                                                                   // 330
      style: "width:200px"                                                                                        // 331
    }                                                                                                             // 330
  },                                                                                                              // 327
  "eventos.$.valor": {                                                                                            // 334
    type: String,                                                                                                 // 335
    optional: true,                                                                                               // 336
    autoform: {                                                                                                   // 337
      style: "width:100px"                                                                                        // 338
    }                                                                                                             // 337
  },                                                                                                              // 334
  "eventos.$.tipoEvento": {                                                                                       // 341
    type: String,                                                                                                 // 342
    label: "Tipo Evento",                                                                                         // 343
    autoform: {                                                                                                   // 344
      type: "select2",                                                                                            // 345
      options: function () {                                                                                      // 346
        return [{                                                                                                 // 347
          label: "PESAJE",                                                                                        // 347
          value: "PESAJE"                                                                                         // 347
        }, {                                                                                                      // 347
          label: "CAMBIO POTRERO",                                                                                // 347
          value: "CAMBIO POTRERO"                                                                                 // 347
        }, {                                                                                                      // 347
          label: "INSEMINADA",                                                                                    // 347
          value: "INSEMINADA"                                                                                     // 347
        }, {                                                                                                      // 347
          label: "MEDICACION",                                                                                    // 347
          value: "MEDICACION"                                                                                     // 347
        }, {                                                                                                      // 347
          label: "INSEMINA",                                                                                      // 347
          value: "INSEMINA"                                                                                       // 347
        }, {                                                                                                      // 347
          label: "PREÑADA",                                                                                       // 347
          value: "PREÑADA"                                                                                        // 347
        }, {                                                                                                      // 347
          label: "FALLECE",                                                                                       // 347
          value: "FALLECE"                                                                                        // 347
        }, {                                                                                                      // 347
          label: "VENTA",                                                                                         // 347
          value: "VENTA"                                                                                          // 347
        }, {                                                                                                      // 347
          label: "OTROS",                                                                                         // 347
          value: "OTROS"                                                                                          // 347
        }];                                                                                                       // 347
      },                                                                                                          // 348
      style: "width:250px"                                                                                        // 349
    }                                                                                                             // 344
  },                                                                                                              // 341
  "eventos.$.detalle": {                                                                                          // 352
    type: String,                                                                                                 // 353
    decimal: true,                                                                                                // 354
    optional: true,                                                                                               // 355
    autoform: {                                                                                                   // 356
      style: "width:215px"                                                                                        // 357
    }                                                                                                             // 356
  },                                                                                                              // 352
  fechaUpdate: {                                                                                                  // 360
    type: Date,                                                                                                   // 361
    label: 'Fecha Update',                                                                                        // 362
    optional: true                                                                                                // 363
  },                                                                                                              // 360
  fechaCelo: {                                                                                                    // 365
    type: Date,                                                                                                   // 366
    label: 'Fecha Celo',                                                                                          // 367
    optional: true                                                                                                // 368
  },                                                                                                              // 365
  enCelo: {                                                                                                       // 370
    type: Boolean,                                                                                                // 371
    label: 'Tiene Celo',                                                                                          // 372
    optional: true                                                                                                // 373
  },                                                                                                              // 370
  carabana: {                                                                                                     // 375
    type: String,                                                                                                 // 376
    label: 'Caravana',                                                                                            // 377
    unique: true                                                                                                  // 378
  },                                                                                                              // 375
  prenada: {                                                                                                      // 380
    type: Boolean,                                                                                                // 381
    label: 'Esta Preñada?'                                                                                        // 382
  },                                                                                                              // 380
  inseminada: {                                                                                                   // 384
    type: Boolean,                                                                                                // 385
    label: 'Esta inseminada?'                                                                                     // 386
  },                                                                                                              // 384
  esReproductor: {                                                                                                // 388
    type: Boolean,                                                                                                // 389
    label: 'Reproductor'                                                                                          // 390
  },                                                                                                              // 388
  cuig: {                                                                                                         // 392
    type: String,                                                                                                 // 393
    label: 'Cuig'                                                                                                 // 394
  },                                                                                                              // 392
  estado: {                                                                                                       // 396
    type: String,                                                                                                 // 397
    label: 'Estado',                                                                                              // 398
    autoform: {                                                                                                   // 399
      type: "select2",                                                                                            // 400
      options: function () {                                                                                      // 401
        return [{                                                                                                 // 402
          label: "ACTIVO",                                                                                        // 402
          value: "ACTIVO"                                                                                         // 402
        }, {                                                                                                      // 402
          label: "INACTIVO",                                                                                      // 402
          value: "INACTIVO"                                                                                       // 402
        }];                                                                                                       // 402
      },                                                                                                          // 403
      style: "width:180px"                                                                                        // 404
    }                                                                                                             // 399
  },                                                                                                              // 396
  nombre: {                                                                                                       // 407
    type: String,                                                                                                 // 408
    label: 'Nombre'                                                                                               // 409
  },                                                                                                              // 407
  raza: {                                                                                                         // 412
    type: String,                                                                                                 // 413
    label: 'Raza'                                                                                                 // 414
  },                                                                                                              // 412
  categoria: {                                                                                                    // 417
    type: String,                                                                                                 // 418
    label: 'Categoría de Pedigre'                                                                                 // 419
  },                                                                                                              // 417
  esMacho: {                                                                                                      // 422
    type: Boolean,                                                                                                // 423
    label: 'Es Macho?',                                                                                           // 424
    optional: true                                                                                                // 425
  },                                                                                                              // 422
  fechaNacimento: {                                                                                               // 427
    type: Date,                                                                                                   // 428
    label: 'Nacimiento'                                                                                           // 429
  },                                                                                                              // 427
  pesoNacimiento: {                                                                                               // 431
    type: String,                                                                                                 // 432
    label: 'Peso Nacimiento'                                                                                      // 433
  }                                                                                                               // 431
}));                                                                                                              // 312
Settings.attachSchema(new SimpleSchema({                                                                          // 441
  valor: {                                                                                                        // 443
    type: String,                                                                                                 // 444
    label: 'Valor'                                                                                                // 445
  },                                                                                                              // 443
  clave: {                                                                                                        // 447
    type: String,                                                                                                 // 448
    label: 'Clave'                                                                                                // 449
  },                                                                                                              // 447
  fecha: {                                                                                                        // 451
    type: Date,                                                                                                   // 452
    label: 'Fecha',                                                                                               // 453
    optional: true                                                                                                // 454
  }                                                                                                               // 451
}), {                                                                                                             // 441
  tracker: Tracker                                                                                                // 457
});                                                                                                               // 457
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"router.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// lib/router.js                                                                                                  //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
applicationController = RouteController.extend({                                                                  // 1
		layoutTemplate: 'layoutApp',                                                                                    // 2
		loadingTemplate: 'loaderGral',                                                                                  // 3
		notFoundTemlplate: 'notFound',                                                                                  // 4
		waitOn: function () {                                                                                           // 6
				return [];                                                                                                    // 7
		},                                                                                                              // 10
		onBeforeAction: function (pause) {                                                                              // 11
				this.render('loaderGral');                                                                                    // 12
                                                                                                                  //
				if (!Meteor.user()) {                                                                                         // 13
						this.render('login');                                                                                       // 14
				} else {                                                                                                      // 14
						this.next();                                                                                                // 15
				}                                                                                                             // 15
		},                                                                                                              // 16
		action: function () {                                                                                           // 17
				if (!this.ready()) {                                                                                          // 18
						this.render('loaderGral');                                                                                  // 19
				} else {                                                                                                      // 20
						this.render();                                                                                              // 22
				}                                                                                                             // 24
		}                                                                                                               // 25
});                                                                                                               // 1
applicationControllerLiquida = RouteController.extend({                                                           // 27
		layoutTemplate: 'layoutApp',                                                                                    // 28
		loadingTemplate: 'loaderGral',                                                                                  // 29
		notFoundTemlplate: 'notFound',                                                                                  // 30
		waitOn: function () {                                                                                           // 32
				return [// Meteor.subscribe('liquidaciones.all',Meteor.user())                                                // 33
				];                                                                                                            // 33
		},                                                                                                              // 36
		onBeforeAction: function (pause) {                                                                              // 37
				this.render('loaderGral');                                                                                    // 38
                                                                                                                  //
				if (!Meteor.user()) {                                                                                         // 39
						this.render('login');                                                                                       // 40
				} else {                                                                                                      // 40
						this.next();                                                                                                // 41
				}                                                                                                             // 41
		},                                                                                                              // 42
		action: function () {                                                                                           // 43
				if (!this.ready()) {                                                                                          // 44
						console.log(Meteor.user());                                                                                 // 45
						this.render('loaderGral');                                                                                  // 46
				} else {                                                                                                      // 47
						this.render();                                                                                              // 49
				}                                                                                                             // 51
		}                                                                                                               // 52
});                                                                                                               // 27
Router.route('/', {                                                                                               // 54
		path: '/',                                                                                                      // 55
		// layoutTemplate: 'layoutVacio',                                                                               // 56
		template: "inicio",                                                                                             // 57
		controller: applicationController                                                                               // 58
});                                                                                                               // 54
Router.route('/inicio', {                                                                                         // 60
		path: '/inicio',                                                                                                // 61
		// layoutTemplate: 'layoutVacio',                                                                               // 62
		template: "inicio",                                                                                             // 63
		controller: applicationController                                                                               // 64
});                                                                                                               // 60
Router.route('/eventosMasivos', {                                                                                 // 66
		path: '/eventosMasivos',                                                                                        // 67
		// layoutTemplate: 'layoutVacio',                                                                               // 68
		template: "eventosMasivos",                                                                                     // 69
		controller: applicationController                                                                               // 70
});                                                                                                               // 66
Router.route('/especies', {                                                                                       // 72
		path: '/especies',                                                                                              // 73
		// layoutTemplate: 'layoutVacio',                                                                               // 74
		template: "especies",                                                                                           // 75
		controller: applicationController                                                                               // 76
});                                                                                                               // 72
Router.route('/potreros', {                                                                                       // 78
		path: '/potreros',                                                                                              // 79
		// layoutTemplate: 'layoutVacio',                                                                               // 80
		template: "potreros",                                                                                           // 81
		controller: applicationController                                                                               // 82
});                                                                                                               // 78
Router.route('animales', {                                                                                        // 84
		path: '/animales',                                                                                              // 85
		template: "animales",                                                                                           // 86
		controller: applicationController                                                                               // 87
});                                                                                                               // 84
Router.route('rodeos', {                                                                                          // 89
		path: '/rodeos',                                                                                                // 90
		template: "rodeos",                                                                                             // 91
		controller: applicationController                                                                               // 92
});                                                                                                               // 89
Router.route('settings', {                                                                                        // 94
		path: '/settings',                                                                                              // 95
		template: "settings",                                                                                           // 96
		controller: applicationController                                                                               // 97
});                                                                                                               // 94
Router.route('informe', {                                                                                         // 99
		path: '/informe',                                                                                               // 100
		template: "informe",                                                                                            // 101
		controller: applicationController                                                                               // 102
});                                                                                                               // 99
Router.route('usuarios', {                                                                                        // 104
		path: '/usuarios',                                                                                              // 105
		template: "usuarios",                                                                                           // 106
		controller: applicationController                                                                               // 107
});                                                                                                               // 104
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"utils.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// lib/utils.js                                                                                                   //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
/*eslint-disable no-unreachable, no-extend-native, no-undef, semi*/String.prototype.lpad = function (padString, length) {
    var str = this;                                                                                               // 3
                                                                                                                  //
    while (str.length < length) {                                                                                 // 4
        str = padString + str;                                                                                    // 5
    }                                                                                                             // 4
                                                                                                                  //
    return str;                                                                                                   // 6
};                                                                                                                // 7
                                                                                                                  //
Date.prototype.addHours = function (h) {                                                                          // 8
    this.setTime(this.getTime() + h * 60 * 60 * 1000);                                                            // 9
    return this;                                                                                                  // 10
};                                                                                                                // 11
                                                                                                                  //
Date.prototype.addDays = function (num) {                                                                         // 12
    var value = this.valueOf();                                                                                   // 13
    value += 86400000 * num;                                                                                      // 14
    return new Date(value);                                                                                       // 15
};                                                                                                                // 16
                                                                                                                  //
String.prototype.getFechaFormato = function () {                                                                  // 17
    var fecha = this;                                                                                             // 19
    var arrFecha = fecha.split("/");                                                                              // 20
    var strString = arrFecha[2] + "-" + arrFecha[1] + "-" + arrFecha[0];                                          // 21
    return new Date(strString);                                                                                   // 22
};                                                                                                                // 23
                                                                                                                  //
String.prototype.getUsuario = function (obj) {                                                                    // 24
    var id = this;                                                                                                // 26
    var usuarios = Session.get("usuarios");                                                                       // 27
    if (usuarios) for (var i = 0; i < usuarios.length; i++) {                                                     // 28
        if (usuarios[i]._id == id) return obj ? usuarios[i] : usuarios[i].profile.nombres;                        // 30
    }                                                                                                             // 29
    return id;                                                                                                    // 32
};                                                                                                                // 33
                                                                                                                  //
String.prototype.lpad = function (padString, length) {                                                            // 34
    var str = this;                                                                                               // 35
                                                                                                                  //
    while (str.length < length) {                                                                                 // 36
        str = padString + str;                                                                                    // 37
    }                                                                                                             // 36
                                                                                                                  //
    return str;                                                                                                   // 38
};                                                                                                                // 39
                                                                                                                  //
String.prototype.capitalizar = function () {                                                                      // 40
    return this.charAt(0).toUpperCase() + this.slice(1);                                                          // 41
};                                                                                                                // 42
                                                                                                                  //
String.prototype.rpad = function (padString, length) {                                                            // 43
    var str = this;                                                                                               // 44
                                                                                                                  //
    while (str.length < length) {                                                                                 // 45
        str = str + padString;                                                                                    // 46
    }                                                                                                             // 45
                                                                                                                  //
    return str;                                                                                                   // 47
};                                                                                                                // 48
                                                                                                                  //
Date.prototype.getFecha = function () {                                                                           // 49
    var value = this.valueOf();                                                                                   // 50
    value += 86400000 * 1;                                                                                        // 51
    var d = new Date(value);                                                                                      // 52
    return d.getDate() + "/" + (d.getMonth() + 1) + "/" + d.getFullYear();                                        // 53
};                                                                                                                // 54
                                                                                                                  //
Date.prototype.getFecha2 = function () {                                                                          // 55
    var value = this.valueOf();                                                                                   // 56
    value += 86400000 * 1;                                                                                        // 57
    var d = new Date(value);                                                                                      // 58
    return d.getDate() + "/" + (d.getMonth() + 1) + "/" + d.getFullYear();                                        // 59
};                                                                                                                // 60
                                                                                                                  //
Date.prototype.getMes = function () {                                                                             // 61
    var value = this.valueOf();                                                                                   // 62
    value += 86400000 * 1;                                                                                        // 63
    var d = new Date(value);                                                                                      // 64
    return d.getMonth() + 1;                                                                                      // 65
};                                                                                                                // 66
                                                                                                                  //
Date.prototype.getDia = function () {                                                                             // 67
    var value = this.valueOf();                                                                                   // 68
    value += 86400000 * 1;                                                                                        // 69
    var d = new Date(value);                                                                                      // 70
    return d.getDate();                                                                                           // 71
};                                                                                                                // 72
                                                                                                                  //
Date.prototype.getAno = function () {                                                                             // 73
    var value = this.valueOf();                                                                                   // 74
    value += 86400000 * 1;                                                                                        // 75
    var d = new Date(value);                                                                                      // 76
    return d.getFullYear();                                                                                       // 77
};                                                                                                                // 78
                                                                                                                  //
Number.prototype.formatMoney = function (n, x, s, c) {                                                            // 79
    var re = '\\d(?=(\\d{' + (x || 3) + '})+' + (n > 0 ? '\\D' : '$') + ')',                                      // 80
        num = this.toFixed(Math.max(0, ~~n));                                                                     // 80
    return (c ? num.replace('.', c) : num).replace(new RegExp(re, 'g'), '$&' + (s || ','));                       // 83
};                                                                                                                // 84
                                                                                                                  //
function validarLargoCBU(cbu) {                                                                                   // 85
    if (cbu.length != 22) {                                                                                       // 86
        return false;                                                                                             // 86
    }                                                                                                             // 86
                                                                                                                  //
    return true;                                                                                                  // 87
}                                                                                                                 // 88
                                                                                                                  //
var validarCodigoBanco = function (codigo) {                                                                      // 90
    if (codigo.length != 8) {                                                                                     // 91
        return false;                                                                                             // 91
    }                                                                                                             // 91
                                                                                                                  //
    var banco = codigo.substr(0, 3);                                                                              // 92
    var digitoVerificador1 = codigo[3];                                                                           // 93
    var sucursal = codigo.substr(4, 3);                                                                           // 94
    var digitoVerificador2 = codigo[7];                                                                           // 95
    var suma = banco[0] * 7 + banco[1] * 1 + banco[2] * 3 + digitoVerificador1 * 9 + sucursal[0] * 7 + sucursal[1] * 1 + sucursal[2] * 3;
    var diferencia = 10 - suma % 10;                                                                              // 99
    return diferencia == digitoVerificador2;                                                                      // 101
};                                                                                                                // 102
                                                                                                                  //
mesLetras = function (mes) {                                                                                      // 103
    if (mes == 1) return "ENERO";                                                                                 // 105
    if (mes == 2) return "FEBRERO";                                                                               // 106
    if (mes == 3) return "MARZO";                                                                                 // 107
    if (mes == 4) return "ABRIL";                                                                                 // 108
    if (mes == 5) return "MAYO";                                                                                  // 109
    if (mes == 6) return "JUNIO";                                                                                 // 110
    if (mes == 7) return "JULIO";                                                                                 // 111
    if (mes == 8) return "AGOSTO";                                                                                // 112
    if (mes == 9) return "SEPTEMBRE";                                                                             // 113
    if (mes == 10) return "OCTUBRE";                                                                              // 114
    if (mes == 11) return "NOVIEMBRE";                                                                            // 115
    if (mes == 12) return "DICIEMBRE";                                                                            // 116
    return "s/a";                                                                                                 // 117
};                                                                                                                // 118
                                                                                                                  //
mesNumeros = function (mes) {                                                                                     // 119
    if (mes == "ENERO") return 1;                                                                                 // 121
    if (mes == "FEBRERO") return 2;                                                                               // 122
    if (mes == "MARZO") return 3;                                                                                 // 123
    if (mes == "ABRIL") return 4;                                                                                 // 124
    if (mes == "MAYO") return 5;                                                                                  // 125
    if (mes == "JUNIO") return 6;                                                                                 // 126
    if (mes == "JULIO") return 7;                                                                                 // 127
    if (mes == "AGOSTO") return 8;                                                                                // 128
    if (mes == "SEPTEMBRE") return 9;                                                                             // 129
    if (mes == "OCTUBRE") return 10;                                                                              // 130
    if (mes == "NOVIEMBRE") return 11;                                                                            // 131
    if (mes == "DICIEMBRE") return 12;                                                                            // 132
    return null;                                                                                                  // 133
};                                                                                                                // 134
                                                                                                                  //
getMeses = function () {                                                                                          // 135
    return ["ENERO", "FEBRERO", "MARZO", "ABRIL", "MAYO", "JUNIO", "JULIO", "AGOSTO", "SEPTEMBRE", "OCTUBRE", "NOVIEMBRE", "DICIEMBRE"];
};                                                                                                                // 138
                                                                                                                  //
ripFechaArchivo = function (fechaDate) {                                                                          // 139
    var st = fechaDate.toLocaleDateString();                                                                      // 141
    var arr = st.split("/");                                                                                      // 142
    return arr[0].lpad("0", 2) + arr[1].lpad("0", 2) + arr[2].lpad("0", 2);                                       // 144
};                                                                                                                // 145
                                                                                                                  //
getImporteTotalSocios = function (arr) {                                                                          // 146
    var sum = 0;                                                                                                  // 148
                                                                                                                  //
    for (var i = 0; i < arr.length; i++) {                                                                        // 149
        sum += arr[i].importe * 1;                                                                                // 149
    }                                                                                                             // 149
                                                                                                                  //
    return sum;                                                                                                   // 150
};                                                                                                                // 151
                                                                                                                  //
ripImporteArchivo = function (importe) {                                                                          // 152
    importe = importe + "";                                                                                       // 154
    var arr = importe.split(".");                                                                                 // 155
    if (arr.length > 1) return arr[0].lpad("0", 8) + arr[1].lpad("0", 2);                                         // 156
    return arr[0].lpad("0", 8) + "00";                                                                            // 157
};                                                                                                                // 158
                                                                                                                  //
var validarCuenta = function (cuenta) {                                                                           // 159
    if (cuenta.length != 14) {                                                                                    // 160
        return false;                                                                                             // 160
    }                                                                                                             // 160
                                                                                                                  //
    var digitoVerificador = cuenta[13];                                                                           // 161
    var suma = cuenta[0] * 3 + cuenta[1] * 9 + cuenta[2] * 7 + cuenta[3] * 1 + cuenta[4] * 3 + cuenta[5] * 9 + cuenta[6] * 7 + cuenta[7] * 1 + cuenta[8] * 3 + cuenta[9] * 9 + cuenta[10] * 7 + cuenta[11] * 1 + cuenta[12] * 3;
    var diferencia = 10 - suma % 10;                                                                              // 163
    return diferencia == digitoVerificador;                                                                       // 164
};                                                                                                                // 165
                                                                                                                  //
validarCBU = function (cbu) {                                                                                     // 167
    return validarLargoCBU(cbu) && validarCodigoBanco(cbu.substr(0, 8)) && validarCuenta(cbu.substr(8, 14));      // 168
};                                                                                                                // 169
                                                                                                                  //
getClaseTipoSocio = function (fechaNac, esActivo, estado) {                                                       // 170
    var tipo = getTipoSocio(fechaNac, esActivo);                                                                  // 171
    if (estado == "BAJA") return "bajaSocio";                                                                     // 172
    var clase = tipo === "PARTICIPANTE" ? "text-warning" : "text-info";                                           // 173
    if (tipo === "ACTIVO") clase = "text-danger";                                                                 // 174
    return clase;                                                                                                 // 175
};                                                                                                                // 176
                                                                                                                  //
geTipoSocioEdad = function (edad, activo) {                                                                       // 177
    var edadAdherente = parseFloat(Settings.findOne({                                                             // 179
        clave: "edadAdherente"                                                                                    // 179
    }).valor);                                                                                                    // 179
    if (activo) return "ACTIVO";                                                                                  // 180
    if (edad >= edadAdherente) return "ADHERENTE";                                                                // 181
    return "PARTICIPANTE";                                                                                        // 183
};                                                                                                                // 184
                                                                                                                  //
getImporteSocioEdad = function (edad, activo) {                                                                   // 185
    var edadAdherente = parseFloat(Settings.findOne({                                                             // 187
        clave: "edadAdherente"                                                                                    // 187
    }).valor);                                                                                                    // 187
    if (activo) return parseFloat(Settings.findOne({                                                              // 188
        clave: "importeActivos"                                                                                   // 188
    }).valor);                                                                                                    // 188
    if (edad >= edadAdherente) return parseFloat(Settings.findOne({                                               // 189
        clave: "imprteAdherentes"                                                                                 // 189
    }).valor);                                                                                                    // 189
    return parseFloat(Settings.findOne({                                                                          // 191
        clave: "importeParticipantes"                                                                             // 191
    }).valor);                                                                                                    // 191
};                                                                                                                // 192
                                                                                                                  //
getEdadSocio = function (fechaNac) {                                                                              // 193
    var hoy = new Date();                                                                                         // 194
    var cumpleanos = new Date(fechaNac);                                                                          // 195
    var edad = hoy.getAno() - cumpleanos.getAno();                                                                // 196
    var m = hoy.getMes() - cumpleanos.getMes();                                                                   // 197
                                                                                                                  //
    if (m < 0 || m === 0 && hoy.getDia() < cumpleanos.getDia()) {                                                 // 199
        edad--;                                                                                                   // 200
    }                                                                                                             // 201
                                                                                                                  //
    return edad;                                                                                                  // 203
};                                                                                                                // 204
                                                                                                                  //
getTipoSocio = function (fechaNac, esActivo) {                                                                    // 205
    var edadAdherente = parseFloat(Settings.findOne({                                                             // 206
        clave: "edadAdherente"                                                                                    // 206
    }).valor);                                                                                                    // 206
    var anos = getEdadSocio(fechaNac);                                                                            // 208
    if (esActivo) return "ACTIVO";                                                                                // 209
    return anos < edadAdherente ? "PARTICIPANTE" : "ADHERENTE";                                                   // 210
};                                                                                                                // 211
                                                                                                                  //
getImporteSocio = function (idSocio) {                                                                            // 212
    var dataParticipantes = Settings.findOne({                                                                    // 214
        clave: "importeParticipantes"                                                                             // 214
    });                                                                                                           // 214
    var dataAdherentes = Settings.findOne({                                                                       // 215
        clave: "importeAdherentes"                                                                                // 215
    });                                                                                                           // 215
    var dataActivos = Settings.findOne({                                                                          // 216
        clave: "importeActivos"                                                                                   // 216
    });                                                                                                           // 216
    var edadAdherente = parseFloat(Settings.findOne({                                                             // 217
        clave: "edadAdherente"                                                                                    // 217
    }).valor);                                                                                                    // 217
    var socio = Socios.findOne({                                                                                  // 219
        _id: idSocio                                                                                              // 219
    });                                                                                                           // 219
    var anos = getEdadSocio(socio.fechaNacimiento);                                                               // 220
    if (socio.esActivo) return dataActivos.valor;                                                                 // 222
    if (anos < edadAdherente) return dataParticipantes.valor;                                                     // 223
    return dataAdherentes.valor;                                                                                  // 224
};                                                                                                                // 225
                                                                                                                  //
getImporteSocioDatos = function (fechaNacimiento, esActivo) {                                                     // 226
    var dataParticipantes = Settings.findOne({                                                                    // 228
        clave: "importeParticipantes"                                                                             // 228
    });                                                                                                           // 228
    var dataAdherentes = Settings.findOne({                                                                       // 229
        clave: "importeAdherentes"                                                                                // 229
    });                                                                                                           // 229
    var dataActivos = Settings.findOne({                                                                          // 230
        clave: "importeActivos"                                                                                   // 230
    });                                                                                                           // 230
    var edadAdherente = parseFloat(Settings.findOne({                                                             // 231
        clave: "edadAdherente"                                                                                    // 231
    }).valor);                                                                                                    // 231
    var anos = getEdadSocio(fechaNacimiento);                                                                     // 234
    if (esActivo) return dataActivos.valor;                                                                       // 236
    if (anos < edadAdherente) return dataParticipantes.valor;                                                     // 237
    return dataAdherentes.valor;                                                                                  // 238
};                                                                                                                // 239
                                                                                                                  //
module.exports = getTipoSocio;                                                                                    // 241
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"main.js":["meteor/meteor",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/main.js                                                                                                 //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
var Meteor = void 0;                                                                                              // 1
module.importSync("meteor/meteor", {                                                                              // 1
  Meteor: function (v) {                                                                                          // 1
    Meteor = v;                                                                                                   // 1
  }                                                                                                               // 1
}, 0);                                                                                                            // 1
                                                                                                                  //
function checkAnimales(arr, Coleccion, idColeccion, idAnimal) {                                                   // 3
  for (var i = 0; i < arr.length; i++) {                                                                          // 5
    if (arr[i].idAnimal == idAnimal) Coleccion.update({                                                           // 6
      _id: idColeccion                                                                                            // 8
    }, {                                                                                                          // 8
      $pull: {                                                                                                    // 9
        "animales": {                                                                                             // 9
          "_id": arr[i]._id                                                                                       // 9
        }                                                                                                         // 9
      }                                                                                                           // 9
    }, {                                                                                                          // 9
      getAutoValues: false                                                                                        // 10
    } // SIN ESTE PARAMETRO NO QUITA!!                                                                            // 10
    );                                                                                                            // 7
  }                                                                                                               // 5
}                                                                                                                 // 12
                                                                                                                  //
function checkRodeos(arr, Coleccion, idColeccion, idRodeo) {                                                      // 13
  for (var i = 0; i < arr.length; i++) {                                                                          // 15
    if (arr[i].idRodeo == idRodeo) Coleccion.update({                                                             // 16
      _id: idColeccion                                                                                            // 18
    }, {                                                                                                          // 18
      $pull: {                                                                                                    // 19
        "rodeos": {                                                                                               // 19
          "_id": arr[i]._id                                                                                       // 19
        }                                                                                                         // 19
      }                                                                                                           // 19
    }, {                                                                                                          // 19
      getAutoValues: false                                                                                        // 20
    } // SIN ESTE PARAMETRO NO QUITA!!                                                                            // 20
    );                                                                                                            // 17
  }                                                                                                               // 15
}                                                                                                                 // 22
                                                                                                                  //
function getAnimales() {                                                                                          // 23
  //var match = { $match: {esMacho:{$eq:soloMachos},estado:"ACTIVO",edad:{$gte:desdeMeses,$lte:hastaMeses}} } ;   // 25
  var match = {                                                                                                   // 26
    $match: {}                                                                                                    // 26
  };                                                                                                              // 26
  var proyecto2 = {                                                                                               // 27
    $project: {                                                                                                   // 28
      edad: {                                                                                                     // 29
        $floor: "$edad"                                                                                           // 29
      },                                                                                                          // 29
      document: "$$ROOT"                                                                                          // 30
    }                                                                                                             // 28
  };                                                                                                              // 27
  var proyecto = {                                                                                                // 34
    $project: {                                                                                                   // 35
      _id: 1,                                                                                                     // 36
      genero: {                                                                                                   // 38
        $cond: [{                                                                                                 // 38
          $eq: ["$esMacho", true]                                                                                 // 38
        }, "MACHO", "HEMBRA"]                                                                                     // 38
      },                                                                                                          // 38
      esHembra: {                                                                                                 // 39
        $cond: [{                                                                                                 // 39
          $eq: ["$esMacho", false]                                                                                // 39
        }, true, false]                                                                                           // 39
      },                                                                                                          // 39
      esMacho: "$esMacho",                                                                                        // 40
      edad: {                                                                                                     // 41
        $divide: [{                                                                                               // 41
          $subtract: [new Date(), "$fechaNacimento"]                                                              // 41
        }, 30 * 24 * 60 * 60 * 1000]                                                                              // 41
      },                                                                                                          // 41
      carbana: "$carbana",                                                                                        // 42
      estado: "$estado",                                                                                          // 43
      nombre: "$nombre",                                                                                          // 44
      carabana: "$carabana",                                                                                      // 45
      esReproductor: "$esReproductor",                                                                            // 46
      inseminada: "$inseminada",                                                                                  // 47
      prenada: "$prenada",                                                                                        // 48
      cuig: "$cuig",                                                                                              // 49
      raza: "$raza",                                                                                              // 50
      fechaCelo: "$fechaCelo",                                                                                    // 51
      eventos: "$eventos",                                                                                        // 52
      pesoNacimiento: "$pesoNacimiento",                                                                          // 53
      categoria: "$categoria",                                                                                    // 54
      fechaNacimento: "$fechaNacimento"                                                                           // 55
    }                                                                                                             // 35
  };                                                                                                              // 34
  var pipeline = [proyecto, match];                                                                               // 60
  return Animales.aggregate(pipeline);                                                                            // 62
}                                                                                                                 // 63
                                                                                                                  //
function getEspecie(dataAnimal) {                                                                                 // 64
  var arr = Especies.find().fetch();                                                                              // 66
  var idEspecie = null;                                                                                           // 67
                                                                                                                  //
  for (var i = 0; i < arr.length; i++) {                                                                          // 68
    var celo = estaCelo(dataAnimal);                                                                              // 69
    if (celo.enCelo && arr[i].enCelo) return arr[i];                                                              // 70
    if (dataAnimal.prenada && arr[i].preniada) return arr[i];                                                     // 71
    if (dataAnimal.esReproductor && arr[i].esReproductor) return arr[i];                                          // 72
    if (dataAnimal.inseminada && arr[i].inseminada) return arr[i];                                                // 73
    console.log(dataAnimal.edad, arr[i].hastaMeses, arr[i].desdeMeses);                                           // 74
    if (dataAnimal.edad >= arr[i].desdeMeses && dataAnimal.edad <= arr[i].hastaMeses && dataAnimal.genero == arr[i].genero) idEspecie = arr[i];
  }                                                                                                               // 76
                                                                                                                  //
  return idEspecie;                                                                                               // 77
}                                                                                                                 // 78
                                                                                                                  //
function quitarEventosAnimal(dataEventoAnimal) {                                                                  // 79
  console.log(dataEventoAnimal);                                                                                  // 80
  return Animales.update({                                                                                        // 81
    _id: dataEventoAnimal.idAnimal                                                                                // 82
  }, {                                                                                                            // 82
    $pull: {                                                                                                      // 83
      "eventos": {                                                                                                // 83
        "_id": dataEventoAnimal._id                                                                               // 83
      }                                                                                                           // 83
    }                                                                                                             // 83
  }, {                                                                                                            // 83
    getAutoValues: false                                                                                          // 84
  } // SIN ESTE PARAMETRO NO QUITA!!                                                                              // 84
  );                                                                                                              // 81
}                                                                                                                 // 86
                                                                                                                  //
function agregarEventosAnimal(dataEventoAnimal, eventoMasivo) {                                                   // 87
  var datosEvento = {                                                                                             // 88
    _id: dataEventoAnimal._id,                                                                                    // 88
    idAnimal: dataEventoAnimal,                                                                                   // 88
    detalle: eventoMasivo.detalle,                                                                                // 88
    fecha: eventoMasivo.fecha,                                                                                    // 88
    tipoEvento: eventoMasivo.tipoEvento,                                                                          // 88
    detalle: eventoMasivo.detalle,                                                                                // 88
    valor: dataEventoAnimal.valor                                                                                 // 88
  };                                                                                                              // 88
  return Animales.update({                                                                                        // 89
    _id: dataEventoAnimal.idAnimal                                                                                // 90
  }, {                                                                                                            // 90
    $push: {                                                                                                      // 91
      "eventos": datosEvento                                                                                      // 91
    }                                                                                                             // 91
  });                                                                                                             // 91
}                                                                                                                 // 93
                                                                                                                  //
function estaCelo(animal) {                                                                                       // 94
  if (!animal.esMacho && !animal.prenada) {                                                                       // 96
    var ahora = new Date();                                                                                       // 97
    var diffTime = Math.abs(ahora - animal.fechaCelo);                                                            // 98
    var diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));                                                   // 99
    var celos = Math.round(diffDays / 20);                                                                        // 100
    var resto = diffDays % 20;                                                                                    // 101
    return {                                                                                                      // 102
      enCelo: celos % 2,                                                                                          // 102
      diasFinaliza: resto                                                                                         // 102
    };                                                                                                            // 102
  }                                                                                                               // 104
                                                                                                                  //
  return {                                                                                                        // 105
    enCelo: false,                                                                                                // 105
    diasFinaliza: 0                                                                                               // 105
  };                                                                                                              // 105
}                                                                                                                 // 107
                                                                                                                  //
function consultaEventosAnimales() {                                                                              // 108
  var match = {                                                                                                   // 110
    $match: {                                                                                                     // 110
      estado: "ACTIVO",                                                                                           // 110
      tipoEvento: "PESO"                                                                                          // 110
    }                                                                                                             // 110
  };                                                                                                              // 110
  var unw = {                                                                                                     // 111
    $unwind: "$eventos"                                                                                           // 111
  };                                                                                                              // 111
  var proyecto = {                                                                                                // 113
    $project: {                                                                                                   // 114
      _id: 1,                                                                                                     // 115
      genero: {                                                                                                   // 117
        $cond: [{                                                                                                 // 117
          $eq: ["$esMacho", true]                                                                                 // 117
        }, "MACHO", "HEMBRA"]                                                                                     // 117
      },                                                                                                          // 117
      esMacho: "$esMacho",                                                                                        // 118
      edad: {                                                                                                     // 119
        $divide: [{                                                                                               // 119
          $subtract: [new Date(), "$fechaNacimento"]                                                              // 119
        }, 30 * 24 * 60 * 60 * 1000]                                                                              // 119
      },                                                                                                          // 119
      carbana: "$carbana",                                                                                        // 120
      estado: "$estado",                                                                                          // 121
      nombre: "$nombre",                                                                                          // 122
      esReproductor: "$esReproductor",                                                                            // 123
      inseminada: "$inseminada",                                                                                  // 124
      prenada: "$prenada",                                                                                        // 125
      fechaCelo: "$fechaCelo",                                                                                    // 126
      cuig: "$cuig",                                                                                              // 127
      raza: "$raza",                                                                                              // 128
      eventos: "$eventos",                                                                                        // 129
      pesoNacimiento: "$pesoNacimiento",                                                                          // 130
      categoria: "$categoria",                                                                                    // 131
      fechaNacimento: "$fechaNacimento",                                                                          // 132
      fechaEvento: "$eventos.fecha",                                                                              // 133
      valorEvento: "$eventos.valor",                                                                              // 134
      tipoEvento: "$eventos.tipoEvento"                                                                           // 135
    }                                                                                                             // 114
  };                                                                                                              // 113
  var pipeline = [proyecto, match, unw];                                                                          // 140
  return Animales.aggregate(pipeline);                                                                            // 142
}                                                                                                                 // 143
                                                                                                                  //
function getObjectoGraph(animal, arrEspecies) {                                                                   // 144
  var aux = [];                                                                                                   // 147
  aux.push(animal.fechaEvento);                                                                                   // 148
                                                                                                                  //
  for (var i = 0; i < arrEspecies.length; i++) {                                                                  // 149
    aux.push(arrEspecies);                                                                                        // 149
  }                                                                                                               // 149
}                                                                                                                 // 150
                                                                                                                  //
Meteor.methods({                                                                                                  // 151
  "consultaPesoEventos": function () {// var arrEspecies=Especies.find().fetch();                                 // 152
    //  var arr=consultaEventosAnimales();                                                                        // 155
    //  var salida=[];                                                                                            // 156
    //  for(var i=0;i<arr.length;i++)salida.push(getObjectoGraph(arr[i]),arrEspecies);                            // 158
  },                                                                                                              // 159
  "consultarTotales": function () {                                                                               // 160
    //var match = { $match: {esMacho:{$eq:soloMachos},estado:"ACTIVO",edad:{$gte:desdeMeses,$lte:hastaMeses}} } ;
    var match = {                                                                                                 // 164
      $match: {}                                                                                                  // 164
    };                                                                                                            // 164
    var grupo = {                                                                                                 // 165
      $group: {                                                                                                   // 165
        totalEdad: {                                                                                              // 165
          $sum: "$edad"                                                                                           // 165
        },                                                                                                        // 165
        cantidad: {                                                                                               // 165
          $sum: 1                                                                                                 // 165
        },                                                                                                        // 165
        _id: {                                                                                                    // 165
          estado: "$estado"                                                                                       // 165
        }                                                                                                         // 165
      }                                                                                                           // 165
    };                                                                                                            // 165
    var proyecto = {                                                                                              // 167
      $project: {                                                                                                 // 168
        _id: 1,                                                                                                   // 169
        genero: {                                                                                                 // 171
          $cond: [{                                                                                               // 171
            $eq: ["$esMacho", true]                                                                               // 171
          }, "MACHO", "HEMBRA"]                                                                                   // 171
        },                                                                                                        // 171
        esHembra: {                                                                                               // 172
          $cond: [{                                                                                               // 172
            $eq: ["$esMacho", false]                                                                              // 172
          }, true, false]                                                                                         // 172
        },                                                                                                        // 172
        esMacho: "$esMacho",                                                                                      // 173
        edad: {                                                                                                   // 174
          $divide: [{                                                                                             // 174
            $subtract: [new Date(), "$fechaNacimento"]                                                            // 174
          }, 30 * 24 * 60 * 60 * 1000]                                                                            // 174
        },                                                                                                        // 174
        carbana: "$carbana",                                                                                      // 175
        estado: "$estado",                                                                                        // 176
        nombre: "$nombre",                                                                                        // 177
        carabana: "$carabana",                                                                                    // 178
        esReproductor: "$esReproductor",                                                                          // 179
        inseminada: "$inseminada",                                                                                // 180
        prenada: "$prenada",                                                                                      // 181
        fechaCelo: "$fechaCelo",                                                                                  // 182
        cuig: "$cuig",                                                                                            // 183
        raza: "$raza",                                                                                            // 184
        eventos: "$eventos",                                                                                      // 185
        pesoNacimiento: "$pesoNacimiento",                                                                        // 186
        categoria: "$categoria",                                                                                  // 187
        fechaNacimento: "$fechaNacimento"                                                                         // 188
      }                                                                                                           // 168
    };                                                                                                            // 167
    var pipeline = [proyecto, match, grupo];                                                                      // 193
    return Animales.aggregate(pipeline);                                                                          // 195
  },                                                                                                              // 196
  "quitarAnimalEvento": function (id, idEventoMasivo) {                                                           // 197
    return EventosMasivos.update({                                                                                // 199
      _id: idEventoMasivo                                                                                         // 200
    }, {                                                                                                          // 200
      $pull: {                                                                                                    // 201
        "animales": {                                                                                             // 201
          "_id": id                                                                                               // 201
        }                                                                                                         // 201
      }                                                                                                           // 201
    }, {                                                                                                          // 201
      getAutoValues: false                                                                                        // 202
    } // SIN ESTE PARAMETRO NO QUITA!!                                                                            // 202
    );                                                                                                            // 199
  },                                                                                                              // 204
  "desaplicarEventoMasivo": function (id) {                                                                       // 205
    var eventoMasivo = EventosMasivos.findOne({                                                                   // 207
      _id: id                                                                                                     // 207
    });                                                                                                           // 207
    var arr = eventoMasivo.animales;                                                                              // 208
                                                                                                                  //
    for (var i = 0; i < arr.length; i++) {                                                                        // 209
      quitarEventosAnimal(arr[i], eventoMasivo);                                                                  // 209
    }                                                                                                             // 209
                                                                                                                  //
    EventosMasivos.update({                                                                                       // 210
      _id: id                                                                                                     // 210
    }, {                                                                                                          // 210
      $set: {                                                                                                     // 210
        estado: "PARA APLICAR"                                                                                    // 210
      }                                                                                                           // 210
    });                                                                                                           // 210
  },                                                                                                              // 211
  "aplicarEventoMasivo": function (id) {                                                                          // 212
    var eventoMasivo = EventosMasivos.findOne({                                                                   // 214
      _id: id                                                                                                     // 214
    });                                                                                                           // 214
    var arr = eventoMasivo.animales;                                                                              // 215
                                                                                                                  //
    for (var i = 0; i < arr.length; i++) {                                                                        // 216
      agregarEventosAnimal(arr[i], eventoMasivo);                                                                 // 216
    }                                                                                                             // 216
                                                                                                                  //
    EventosMasivos.update({                                                                                       // 217
      _id: id                                                                                                     // 217
    }, {                                                                                                          // 217
      $set: {                                                                                                     // 217
        estado: "APLICADO"                                                                                        // 217
      }                                                                                                           // 217
    });                                                                                                           // 217
  },                                                                                                              // 219
  "eventos.quitar": function (idEvento, idAnimal) {                                                               // 220
    return Animales.update({                                                                                      // 222
      _id: idAnimal                                                                                               // 223
    }, {                                                                                                          // 223
      $pull: {                                                                                                    // 224
        "eventos": {                                                                                              // 224
          "_id": idEvento                                                                                         // 224
        }                                                                                                         // 224
      }                                                                                                           // 224
    }, {                                                                                                          // 224
      getAutoValues: false                                                                                        // 225
    } // SIN ESTE PARAMETRO NO QUITA!!                                                                            // 225
    );                                                                                                            // 222
  },                                                                                                              // 227
  "animales.find": function () {                                                                                  // 228
    var arr = getAnimales();                                                                                      // 229
                                                                                                                  //
    for (var i = 0; i < arr.length; i++) {                                                                        // 230
      var celo = estaCelo(arr[i]);                                                                                // 231
      var especieAnimal = getEspecie(arr[i]);                                                                     // 232
      arr[i].especie = especieAnimal;                                                                             // 233
      arr[i].tieneCelo = celo.enCelo;                                                                             // 234
      arr[i].edad = Math.round(arr[i].edad);                                                                      // 235
      arr[i].diasFinalizaCelo = celo.diasFinaliza;                                                                // 236
      arr[i].idEspecie = especieAnimal ? especieAnimal._id : null;                                                // 237
    }                                                                                                             // 238
                                                                                                                  //
    return arr;                                                                                                   // 239
  },                                                                                                              // 240
  "rodeos.all": function () {                                                                                     // 241
    var arr = Rodeos.find().fetch();                                                                              // 242
    return arr;                                                                                                   // 243
  },                                                                                                              // 244
  "actualizarAnimal": function (doc, idAnimal) {                                                                  // 245
    if (doc.tipoEvento == "FALLECE") Animales.update({                                                            // 246
      _id: idAnimal                                                                                               // 246
    }, {                                                                                                          // 246
      $set: {                                                                                                     // 246
        estado: "INACTIVO"                                                                                        // 246
      }                                                                                                           // 246
    });                                                                                                           // 246
    if (doc.tipoEvento == "VENTA") Animales.update({                                                              // 247
      _id: idAnimal                                                                                               // 247
    }, {                                                                                                          // 247
      $set: {                                                                                                     // 247
        estado: "INACTIVO"                                                                                        // 247
      }                                                                                                           // 247
    });                                                                                                           // 247
  },                                                                                                              // 248
  "consultarDeAnimales": function (colString, id) {                                                               // 249
    var Coleccion = module.runModuleSetters(eval(colString));                                                     // 251
    return Coleccion.findOne({                                                                                    // 252
      _id: id                                                                                                     // 252
    }).animales ? Coleccion.findOne({                                                                             // 252
      _id: id                                                                                                     // 252
    }).animales : [];                                                                                             // 252
  },                                                                                                              // 253
  "consultarDeRodeos": function (colString, id) {                                                                 // 254
    var Coleccion = module.runModuleSetters(eval(colString));                                                     // 256
    return Coleccion.findOne({                                                                                    // 257
      _id: id                                                                                                     // 257
    }).rodeos ? Coleccion.findOne({                                                                               // 257
      _id: id                                                                                                     // 257
    }).rodeos : [];                                                                                               // 257
  },                                                                                                              // 258
  "quitarDeAnimales": function (doc, tipo) {                                                                      // 259
    var Coleccion = module.runModuleSetters(eval(tipo));                                                          // 260
    var arr = Coleccion.find({}).fetch();                                                                         // 261
                                                                                                                  //
    for (var i = 0; i < arr.length; i++) {                                                                        // 262
      checkAnimales(arr[i].animales ? arr[i].animales : [], Coleccion, arr[i]._id, doc.idAnimal);                 // 263
    }                                                                                                             // 262
  },                                                                                                              // 265
  "quitarDeRodeos": function (doc, tipo) {                                                                        // 266
    var Coleccion = module.runModuleSetters(eval(tipo));                                                          // 267
    var arr = Coleccion.find({}).fetch();                                                                         // 268
                                                                                                                  //
    for (var i = 0; i < arr.length; i++) {                                                                        // 269
      checkRodeos(arr[i].rodeos ? arr[i].rodeos : [], Coleccion, arr[i]._id, doc.idRodeo);                        // 270
    }                                                                                                             // 269
  },                                                                                                              // 272
  "pacientes.save": function (data) {                                                                             // 273
    var existe = Pacientes.findOne({                                                                              // 274
      nroAfiliado: data.nroAfiliado,                                                                              // 274
      idObraSocial: data.idObraSocial                                                                             // 274
    });                                                                                                           // 274
    if (existe) return Pacientes.update({                                                                         // 275
      _id: existe._id                                                                                             // 275
    }, {                                                                                                          // 275
      $set: {                                                                                                     // 275
        nombrePaciente: data.nombrePaciente,                                                                      // 275
        nroAfiliado: data.nroAfiliado,                                                                            // 275
        fechaUpdate: data.fechaUpdate,                                                                            // 275
        idUsuarioCambia: data.idUsuarioCambia                                                                     // 275
      }                                                                                                           // 275
    });                                                                                                           // 275
    return Pacientes.insert(data);                                                                                // 276
  },                                                                                                              // 277
  'users.cargarInicial': function (data) {                                                                        // 278
    var hayUsuarios = Meteor.users.find().count() > 0;                                                            // 279
                                                                                                                  //
    if (!hayUsuarios) {                                                                                           // 280
      var perfil = {                                                                                              // 281
        nombres: "alejandro",                                                                                     // 281
        rol: "administrador"                                                                                      // 281
      };                                                                                                          // 281
      Accounts.createUser({                                                                                       // 283
        username: "admin",                                                                                        // 283
        password: "admin",                                                                                        // 283
        profile: perfil                                                                                           // 283
      });                                                                                                         // 283
    }                                                                                                             // 284
  },                                                                                                              // 285
  "liquidaciones.guardar": function (idLiquidacion, facturas) {                                                   // 286
    return Liquidaciones.update({                                                                                 // 287
      _id: idLiquidacion                                                                                          // 287
    }, {                                                                                                          // 287
      $set: {                                                                                                     // 287
        estado: "CHECKEADO",                                                                                      // 287
        facturas: facturas                                                                                        // 287
      }                                                                                                           // 287
    });                                                                                                           // 287
  },                                                                                                              // 289
  "obrasSociales.all": function () {                                                                              // 290
    return ObrasSociales.find().fetch();                                                                          // 292
  },                                                                                                              // 293
  "liquidaciones.buscar": function (desde, hasta, usuario) {                                                      // 294
    var userLogueado = Meteor.users.findOne({                                                                     // 296
      _id: Meteor.userId()                                                                                        // 296
    });                                                                                                           // 296
                                                                                                                  //
    if (userLogueado) {                                                                                           // 298
      if (userLogueado.profile.rol === "secretaria") return Liquidaciones.find({                                  // 300
        idUsuario: userLogueado._id,                                                                              // 300
        fecha: {                                                                                                  // 300
          $gte: desde,                                                                                            // 300
          $lte: hasta                                                                                             // 300
        }                                                                                                         // 300
      }).fetch();                                                                                                 // 300
      console.log(usuario);                                                                                       // 301
      var match = {                                                                                               // 302
        fecha: {                                                                                                  // 302
          $gte: desde,                                                                                            // 302
          $lte: hasta                                                                                             // 302
        }                                                                                                         // 302
      };                                                                                                          // 302
      if (usuario) match['idUsuario'] = usuario._id;                                                              // 303
      console.log(match);                                                                                         // 304
      return Liquidaciones.find(match).fetch();                                                                   // 305
    }                                                                                                             // 306
                                                                                                                  //
    return [];                                                                                                    // 307
  },                                                                                                              // 309
  "liquidaciones.buscarMasivo": function (fechaDesde, fechaHasta, idObraSocial) {                                 // 310
    console.log(fechaDesde, fechaHasta, idObraSocial);                                                            // 311
    var liquidaciones = Liquidaciones.find({                                                                      // 313
      fecha: {                                                                                                    // 313
        $gte: fechaDesde,                                                                                         // 313
        $lte: fechaHasta                                                                                          // 313
      }                                                                                                           // 313
    }).fetch();                                                                                                   // 313
    var data = [];                                                                                                // 314
    console.log(Liquidaciones.find().fetch());                                                                    // 315
    if (liquidaciones) for (var i = 0; i < liquidaciones.length; i++) {                                           // 316
      var idLiquidacion = liquidaciones[i]._id;                                                                   // 318
      var arr = getFacturasOs(liquidaciones[i].facturas, idObraSocial);                                           // 319
      var profesional = getUsuario(liquidaciones[i].idUsuario);                                                   // 320
      data.push({                                                                                                 // 321
        estado: liquidaciones[i].estado,                                                                          // 321
        profesional: profesional,                                                                                 // 321
        facturas: arr,                                                                                            // 321
        idObraSocial: idObraSocial,                                                                               // 321
        idLiquidacion: idLiquidacion                                                                              // 321
      });                                                                                                         // 321
    }                                                                                                             // 323
    return data;                                                                                                  // 324
  },                                                                                                              // 325
  'nomencladores.all': function () {                                                                              // 326
    return Nomencladores.find({});                                                                                // 327
  },                                                                                                              // 328
  "users.perfil": function (id) {                                                                                 // 329
    return Meteor.users.findOne({                                                                                 // 331
      _id: id                                                                                                     // 331
    }).profile;                                                                                                   // 331
  },                                                                                                              // 332
  'users.list': function (data) {                                                                                 // 333
    return Meteor.users.find().fetch();                                                                           // 334
  },                                                                                                              // 335
  'users.one': function (id) {                                                                                    // 337
    return Meteor.users.find({                                                                                    // 338
      _id: id                                                                                                     // 338
    });                                                                                                           // 338
  },                                                                                                              // 339
  'users.add': function (usuario, clave, perfil) {                                                                // 340
    return Accounts.createUser({                                                                                  // 341
      username: usuario,                                                                                          // 341
      password: clave,                                                                                            // 341
      profile: perfil                                                                                             // 341
    });                                                                                                           // 341
  },                                                                                                              // 342
  'users.update': function (_id, usuario, perfil) {                                                               // 343
    return Meteor.users.update({                                                                                  // 344
      _id: _id                                                                                                    // 344
    }, {                                                                                                          // 344
      $set: {                                                                                                     // 344
        profile: perfil,                                                                                          // 344
        username: usuario                                                                                         // 344
      }                                                                                                           // 344
    });                                                                                                           // 344
  },                                                                                                              // 345
  'users.remove': function (_id) {                                                                                // 346
    return Meteor.users.remove({                                                                                  // 347
      _id: _id                                                                                                    // 347
    });                                                                                                           // 347
  },                                                                                                              // 348
  'users.resetPassword': function (_id, clave) {                                                                  // 349
    return Accounts.setPassword(_id, clave);                                                                      // 350
  },                                                                                                              // 351
  'settings.generarVariables': function () {                                                                      // 352
    if (!Settings.findOne({                                                                                       // 353
      clave: "hostInyeccion"                                                                                      // 353
    })) Settings.insert({                                                                                         // 353
      clave: "hostInyeccion",                                                                                     // 353
      valor: "192.155.543.5"                                                                                      // 353
    });                                                                                                           // 353
    if (!Settings.findOne({                                                                                       // 354
      clave: "usuarioInyeccion"                                                                                   // 354
    })) Settings.insert({                                                                                         // 354
      clave: "usuarioInyeccion",                                                                                  // 354
      valor: "root"                                                                                               // 354
    });                                                                                                           // 354
    if (!Settings.findOne({                                                                                       // 355
      clave: "claveInyeccion"                                                                                     // 355
    })) Settings.insert({                                                                                         // 355
      clave: "claveInyeccion",                                                                                    // 355
      valor: "vertrigo"                                                                                           // 355
    });                                                                                                           // 355
    if (!Settings.findOne({                                                                                       // 356
      clave: "dbInyeccion"                                                                                        // 356
    })) Settings.insert({                                                                                         // 356
      clave: "dbInyeccion",                                                                                       // 356
      valor: "asociacion"                                                                                         // 356
    });                                                                                                           // 356
    if (!Settings.findOne({                                                                                       // 357
      clave: "proxNroLiquidacion"                                                                                 // 357
    })) Settings.insert({                                                                                         // 357
      clave: "proxNroLiquidacion",                                                                                // 357
      valor: "1"                                                                                                  // 357
    });                                                                                                           // 357
  },                                                                                                              // 358
  'settings.remove': function (id) {                                                                              // 359
    return Settings.remove({                                                                                      // 360
      _id: id                                                                                                     // 360
    });                                                                                                           // 360
  },                                                                                                              // 361
  "settings.autoincrementaNroLiquidacion": function () {                                                          // 362
    console.log("fdd");                                                                                           // 363
    var nuevoValor = Number(Settings.findOne({                                                                    // 364
      clave: "proxNroLiquidacion"                                                                                 // 364
    }).valor) + 1;                                                                                                // 364
    Settings.update({                                                                                             // 365
      clave: "proxNroLiquidacion"                                                                                 // 365
    }, {                                                                                                          // 365
      $set: {                                                                                                     // 365
        valor: nuevoValor                                                                                         // 365
      }                                                                                                           // 365
    });                                                                                                           // 365
    console.log("cambio");                                                                                        // 366
  },                                                                                                              // 367
  "remote.syncLiquidacion": function (idLiquidacion, idOs) {                                                      // 368
    var Future = Npm.require('fibers/future');                                                                    // 370
                                                                                                                  //
    var fut1 = new Future();                                                                                      // 371
                                                                                                                  //
    var exec = Npm.require("child_process").exec;                                                                 // 372
                                                                                                                  //
    var path = process.cwd() + '/../web.browser/app/shellPython/syncLiquidacion.py';                              // 373
    var command = "python " + path + " " + idLiquidacion + " " + idOs;                                            // 375
    exec(command, function (error, stdout, stderr) {                                                              // 377
      console.log(stdout);                                                                                        // 378
      fut1.return(stderr);                                                                                        // 379
    });                                                                                                           // 380
    return fut1.wait();                                                                                           // 381
    return fut1.wait();                                                                                           // 383
  },                                                                                                              // 384
  "remote.syncOs": function () {                                                                                  // 385
    Future = Npm.require('fibers/future');                                                                        // 387
    var fut1 = new Future();                                                                                      // 388
                                                                                                                  //
    var exec = Npm.require("child_process").exec;                                                                 // 389
                                                                                                                  //
    var path = process.cwd() + '/../web.browser/app/shellPython/importarOs.py';                                   // 391
    var command = "python " + path;                                                                               // 393
    exec(command, function (error, stdout, stderr) {                                                              // 394
      if (error) {                                                                                                // 395
        console.log(error);                                                                                       // 396
        throw new Meteor.Error(500, command + " failed");                                                         // 397
      }                                                                                                           // 398
                                                                                                                  //
      console.log(stdout);                                                                                        // 399
      fut1.return(stdout.toString());                                                                             // 400
    });                                                                                                           // 401
    return fut1.wait();                                                                                           // 402
    return fut1.wait();                                                                                           // 404
  },                                                                                                              // 405
  'liquidaciones.one': function (id) {                                                                            // 406
    return Liquidaciones.findOne({                                                                                // 408
      _id: id                                                                                                     // 408
    });                                                                                                           // 408
  },                                                                                                              // 409
  'liquidaciones.remove': function (id) {                                                                         // 410
    return Liquidaciones.remove({                                                                                 // 412
      _id: id                                                                                                     // 412
    });                                                                                                           // 412
  },                                                                                                              // 413
  "liquidaciones.updateFactura": function (data, res) {                                                           // 414
    console.log(data);                                                                                            // 415
    console.log(res);                                                                                             // 416
    return true;                                                                                                  // 417
  },                                                                                                              // 418
  'liquidaciones_factura.remove': function (idLiquidacion, id) {                                                  // 419
    return Liquidaciones.update({                                                                                 // 420
      _id: idLiquidacion                                                                                          // 421
    }, {                                                                                                          // 421
      $pull: {                                                                                                    // 422
        "facturas": {                                                                                             // 422
          "_id": id                                                                                               // 422
        }                                                                                                         // 422
      }                                                                                                           // 422
    }, {                                                                                                          // 422
      getAutoValues: false                                                                                        // 423
    } // SIN ESTE PARAMETRO NO QUITA!!                                                                            // 423
    );                                                                                                            // 420
  }                                                                                                               // 425
});                                                                                                               // 151
                                                                                                                  //
if (Meteor.isServer) {                                                                                            // 428
  Meteor.publish('animales.all', function () {                                                                    // 431
    return Animales.find();                                                                                       // 432
  });                                                                                                             // 433
  Meteor.publish('eventosMasivos.all', function () {                                                              // 434
    return EventosMasivos.find();                                                                                 // 435
  });                                                                                                             // 436
  Meteor.publish('potreros.all', function () {                                                                    // 437
    return Potreros.find();                                                                                       // 438
  });                                                                                                             // 439
  Meteor.publish('rodeos.all', function () {                                                                      // 440
    return Rodeos.find();                                                                                         // 441
  });                                                                                                             // 442
  Meteor.publish('especies.all', function () {                                                                    // 443
    return Especies.find();                                                                                       // 444
  });                                                                                                             // 445
  Meteor.publish('settings.all', function () {                                                                    // 446
    return Settings.find();                                                                                       // 447
  });                                                                                                             // 448
}                                                                                                                 // 450
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},{"extensions":[".js",".json"]});
require("./lib/collections.js");
require("./lib/router.js");
require("./lib/utils.js");
require("./server/main.js");
//# sourceMappingURL=app.js.map

(function () {



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['risul:bootstrap-colorpicker'] = {};

})();

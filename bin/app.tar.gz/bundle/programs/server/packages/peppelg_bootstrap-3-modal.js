(function () {



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['peppelg:bootstrap-3-modal'] = {};

})();
